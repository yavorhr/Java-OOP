package robotService.entities.services;

public class MainService extends BaseService {

    public MainService(String name) {
        super(name, 30);
    }
}
