package fairyShop.models;

public class Happy extends BaseHelper{
    public Happy(String name) {
        super(name, 100);
    }
}
