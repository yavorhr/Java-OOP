package fairyShop.core;

public interface Engine extends Runnable {
    void run();
}
