package handball.entities.team;

public interface Team {
    void setName(String name);

    void play();

    String getName();

    int getAdvantage();


}
