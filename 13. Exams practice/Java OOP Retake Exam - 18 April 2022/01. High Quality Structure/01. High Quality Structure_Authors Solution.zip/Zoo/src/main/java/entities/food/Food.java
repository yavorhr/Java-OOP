package entities.food;

public interface Food {
    int getCalories();
    double getPrice();
}
