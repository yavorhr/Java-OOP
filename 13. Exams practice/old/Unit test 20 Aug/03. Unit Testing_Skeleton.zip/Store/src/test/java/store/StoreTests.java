package store;

import org.junit.Assert;
import org.junit.Test;

public class StoreTests {
    //TODO: Test Store class
}