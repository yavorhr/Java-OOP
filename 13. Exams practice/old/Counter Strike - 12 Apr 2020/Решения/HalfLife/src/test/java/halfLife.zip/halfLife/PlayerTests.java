package halfLife;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;


public class PlayerTests {
    private Player player;
    private Player playerOne;
    private Player playerTwo;

    @Before
    public void SetUp() {
        player = new Player("Pesho", 100);
        playerOne = new Player("PlayerOne", 36);
        playerTwo = new Player("PlayerTwo", 42);
    }

    @Test
    public void testCreatePlayerInstance() {
        String actualName = player.getUsername();
        String expectedName = "Pesho";
        Assert.assertEquals(expectedName, actualName);

    }

    @Test(expected = NullPointerException.class)
    public void testIfPlayerNotNull() {
        player = new Player(null, 20);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testHealthIsGreaterThanZero() {
        new Player("Pesho", -1);
    }

    @Test
    public void testGetHealth() {
        int expectedHealth = 100;
        int actualHealth = player.getHealth();
        Assert.assertEquals(expectedHealth, actualHealth);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testHealthNotBelowZero() {
        Player playerFor = new Player("test", -30);
    }

    @Test
    public void testGetGuns() {
        int guns = player.getGuns().size();
        int expectedNumberOfGuns = 0;
        Assert.assertEquals(expectedNumberOfGuns, guns);
    }

//    @Test(expected = IllegalStateException.class)
//    public void testTakeDamageBelowZero() {
//
//    }

    @Test
    public void testTakeDamageWorkCorrect() {
        player.takeDamage(50);
        int actualHealth = player.getHealth();
        int expectedHealth = 50;
        Assert.assertEquals(expectedHealth, actualHealth);
    }

    @Test
    public void testUserName() {
        String expectedUsername = "Pesho";
        String actual = player.getUsername();
        Assert.assertEquals(expectedUsername, actual);
    }

    @Test(expected = NullPointerException.class)
    public void userNameNullTest() {
        Player player = new Player(null, 30);
    }

    @Test(expected = NullPointerException.class)
    public void gunIsNull() {
        player.addGun(null);
    }

    @Test
    public void testAddGun() {
        Gun gun = new Gun("Pistol", 123);
        player.addGun(gun);
        Assert.assertEquals(1, player.getGuns().size());
    }

    @Test
    public void testRemoveGun() {
        Gun gun = new Gun("Rifle", 13);
        player.addGun(gun);
        boolean actualResult = player.removeGun(gun);
        Assert.assertTrue(actualResult);
    }

    @Test
    public void testGetGun() {
        Gun gun = new Gun("Rifle", 13);
        player.addGun(gun);
        boolean actualResult = player.removeGun(gun);
        Assert.assertTrue(actualResult);
    }

    @Test
    public void testGetValidGun() {
        Gun gun = new Gun("Rifle", 123);
        player.addGun(gun);
        Gun expectedGun = gun;
        Gun actualGun = player.getGun(gun.getName());
        Assert.assertEquals(gun, actualGun);
    }
}
