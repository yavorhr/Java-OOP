package bank.entities.loan;

public class MortgageLoan extends BaseLoan {

    public MortgageLoan() {
        super(3, 50000);
    }
}
