package computers;

import org.junit.Test;

import static org.junit.Assert.*;

public class ComputerTest {

   //TODO: TEST ALL THE FUNCTIONALITY OF THE PROVIDED CLASS Computer
}