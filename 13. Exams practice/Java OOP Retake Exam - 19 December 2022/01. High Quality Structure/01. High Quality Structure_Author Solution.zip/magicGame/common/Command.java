package magicGame.common;

public enum Command {
    AddMagic,
    AddMagician,
    Report,
    StartGame,
    Exit
}
