package christmasPastryShop.entities.delicacies;

public class Stolen extends BaseDelicacy {

    public Stolen(String name, double price) {
        super(name, 250.0, price);
    }
}
