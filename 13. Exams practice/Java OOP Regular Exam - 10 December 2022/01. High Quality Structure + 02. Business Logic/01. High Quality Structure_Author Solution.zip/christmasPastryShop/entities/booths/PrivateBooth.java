package christmasPastryShop.entities.booths;

public class PrivateBooth extends BaseBooth {

    public PrivateBooth(Integer boothNumber, Integer capacity) {
        super(boothNumber, capacity, 3.5);
    }
}
