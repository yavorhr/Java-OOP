package harpoonDiver.core;

public class ControllerImpl implements Controller{
    @Override
    public String addDiver(String kind, String diverName) {
        //TODO
        return null;
    }

    @Override
    public String addDivingSite(String siteName, String... seaCreatures) {
        //TODO
        return null;
    }

    @Override
    public String removeDiver(String diverName) {
        //TODO
        return null;
    }

    @Override
    public String startDiving(String siteName) {
        //TODO
        return null;
    }

    @Override
    public String getStatistics() {
        //TODO
        return null;
    }
}
