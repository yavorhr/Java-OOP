package climbers.models.list;

import java.util.Collection;

public interface Roster {
    Collection<String> getPeaks();
}
