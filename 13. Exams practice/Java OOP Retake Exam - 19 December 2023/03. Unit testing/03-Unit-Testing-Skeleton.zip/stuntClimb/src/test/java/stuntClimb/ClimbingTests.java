package stuntClimb;



public class ClimbingTests {


}
